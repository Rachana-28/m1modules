﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestEntity;
using System.Text.RegularExpressions;
using System.IO;
namespace GuestBL
{
    public class GuestBLL
    {
        private static bool ValidateGuest(Guest guest)
        {
            StringBuilder sb = new StringBuilder();
            bool validGuest = true;
            if (guest.GuestID ==string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest ID is required");
            }
            else if (!Regex.IsMatch(guest.GuestID, @"^[0-9]{3}$"))
            {
                validGuest = false;
                Console.WriteLine("Guest ID is not in correct format,ID should be 3 digits long");
            }
            if (guest.GuestName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Name is required");
            }
            else if (!Regex.IsMatch(guest.GuestName, @"^[A-Z][a-z]{2,50}$"))
            {
                validGuest = false;
                Console.WriteLine("Guest Name is not in correct format");
            }
            if (guest.Number == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Number is required");
            }
            else if (!Regex.IsMatch(guest.Number, "[6-9][0-9]{9}"))
            {
                validGuest = false;
                Console.WriteLine("Guest Number is not in correct format");
            }
            if (validGuest == false)
            {
                throw new GuestException.GuestEx(sb.ToString());
            }
            return validGuest;
        }
        public static bool AddGuestBL(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateGuest(newGuest))
                {
                    guestAdded = GuestDAL.GuestDL.AddGuestDAL(newGuest);
                }
            }
            catch(GuestException.GuestEx e)
            {
                throw e;
            }
            catch(Exception e)
            {
                throw e;
            }
            return guestAdded;
        }
        public static List<Guest> ListAllGuestBL()
        {
            List<Guest> guestList = null;
            try
            {
                guestList = GuestDAL.GuestDL.ListAllGuestDAL();

            }
            catch(GuestException.GuestEx e)
            {
                throw e;
            }
            catch(Exception e)
            {
                throw e;
            }
            return guestList;
        }
        public static bool DeleteGuestBL(string delProduct)

        {
            bool deleteguest = false;
            try
            {
                if (delProduct != string.Empty)
                {
                    deleteguest = GuestDAL.GuestDL.DeleteGuestDAL(delProduct);
                }
            }
            catch (GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return deleteguest;
        }
        public static Guest SearchGuestBL(string searchGuest)

        {
            Guest searchguest = null;
            try
            {
                searchguest = GuestDAL.GuestDL.SearchGuestDAL(searchGuest);

            }
            catch (GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return searchguest;
        }

        public static bool UpdateGuestBL(Guest updateGuest)

        {
            bool updateguest = false;
            try
            {
                if (ValidateGuest(updateGuest))
                {
                    GuestDAL.GuestDL guestDAL = new GuestDAL.GuestDL();
                    updateguest = GuestDAL.GuestDL.UpdateGuestDAL(updateGuest);
                }
            }
            catch (GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return updateguest;
        }

        public static void SetSerialization()
        {
            if (GuestDAL.GuestDL.guestList!= null)
            {
                GuestDAL.GuestDL.SetSerialization();
            }
        }



        public static void setlist()
        {
            try
            {
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + GuestDAL.GuestDL.filename))
                    GuestDAL.GuestDL.SetList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

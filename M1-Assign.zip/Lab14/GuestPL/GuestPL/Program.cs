﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestEntity;
namespace GuestPL
{
    class Program
    {
        static void Main(string[] args)
        {
            GuestBL.GuestBLL.setlist();
            int choice;
            do
            {
                Menu();
                Console.WriteLine("Enter the choice");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        ListAllGuest();
                        break;
                    case 3:
                        UpdateGuest();
                        break;
                    case 4:
                        SearchGuest();
                        break;
                    case 5:
                        DeleteGuest();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Enter the valid choice");
                        SetSerialization();
                        break;
                }
            } while (choice > 0 && choice < 7);
            
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e) { SetSerialization(); }
        private static void Menu()
        {
            Console.WriteLine("===========================Guest Contact Details=====================================");
            Console.WriteLine("1.Add Guest\n2.List All Guest\n3.Update Guest\n4.Search Guest\n5.Delete Guest\n6.Exit");
        }
        private static void AddGuest()
        {
            try
            {
                Guest guest = new Guest();
                Console.WriteLine("Enter the Guest ID");
                guest.GuestID = Console.ReadLine();
                Console.WriteLine("Enter the Guest Name");
                guest.GuestName = Console.ReadLine();
                Console.WriteLine("Enter the Guest Number");
                guest.Number = Console.ReadLine();
                bool guestAdded = GuestBL.GuestBLL.AddGuestBL(guest);
                if (guestAdded)
                {
                    Console.WriteLine("Guest Details has been added successfully");
                }
                else
                {
                    Console.WriteLine("Guest Details not added");
                }
            }
            catch(GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void ListAllGuest()
        {
            try
            {
                List<Guest> guestList = GuestBL.GuestBLL.ListAllGuestBL();
                if (guestList != null && guestList.Count > 0)
                {
                    Console.WriteLine("============================================================================");
                    Console.WriteLine("Guest ID\t\tGuest Name\t\tGuest Number");
                    foreach (Guest g in guestList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", g.GuestID, g.GuestName, g.Number);
                    }
                    Console.WriteLine("============================================================================");
                }
                else
                {
                    Console.WriteLine("Guest Details not found");
                }
            }
            catch(GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void UpdateGuest()
        {
            try
            {
                string updatedguest;
                Console.WriteLine("Enter the guest id to be update");
                updatedguest = Console.ReadLine();
                Guest updatedGuestID = GuestBL.GuestBLL.SearchGuestBL(updatedguest);
                if (updatedGuestID != null)
                {
                    Console.WriteLine("Guest name to be update");
                    updatedGuestID.GuestName = Console.ReadLine();
                    Console.WriteLine("Guest number to be update");
                    updatedGuestID.Number = Console.ReadLine();
                    bool guestAdded = GuestBL.GuestBLL.UpdateGuestBL(updatedGuestID);
                    if (guestAdded)
                    {
                        Console.WriteLine("Guest Details Updated");
                    }
                    else
                    {
                        Console.WriteLine("Guest Details not updated");
                    }
                }
            }
            catch(GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void SearchGuest()
        {
            try
            {
                string searchguest;
                Console.WriteLine("Enter serial number to be search");
                searchguest = Console.ReadLine();
                Guest searchguestid = GuestBL.GuestBLL.SearchGuestBL(searchguest);
                if (searchguestid != null)
                {
                    Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++");
                    Console.WriteLine("Guest Id\t\tGuest Name\t\tNumber");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchguestid.GuestID, searchguestid.GuestName, searchguestid.Number);

                }
                else
                {
                    Console.WriteLine("No guest details are available");
                }
            }
            catch (GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void DeleteGuest()
        {
            try
            {
                string deleteguest;
                Console.WriteLine("Enter the guest id to be delete");
                deleteguest = Console.ReadLine();
                bool guestdeleted = GuestBL.GuestBLL.DeleteGuestBL(deleteguest);
                if (guestdeleted)
                {
                    Console.WriteLine("Guest details deleted");
                }
                else
                {
                    Console.WriteLine("Guest details not deleted");
                }
            }
            catch (GuestException.GuestEx e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void SetSerialization()
        {
            GuestBL.GuestBLL.SetSerialization();
        }
    }
}

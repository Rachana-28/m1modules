﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppSaving
{
    public interface Account
    {
        void CalculateInterestICICI(int number);
        void CalculateInterestHSBC(int number);
    }
    public class Saving : Account
    {
        Account account;
        int number;

        public void CalculateInterestICICI(int number)
        {
            int interest = (number * 7 / 100);
            Console.WriteLine("Interest- " +interest);
        }
        public void CalculateInterestHSBC(int number)
        {
            int interest = (number * 5 / 100);
            Console.WriteLine("Interest- " + interest);
        }





    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 1.ICICI\n2.HSBC");
            int n = int.Parse(Console.ReadLine());
            switch(n)
            {
                case 1:
                    Saving sv = new Saving();
                    Console.WriteLine("Enter balance in account");
                    int bal = int.Parse(Console.ReadLine());
                    sv.CalculateInterestICICI(bal);


                    break;
                case 2:
                    Saving sv1 = new Saving();
                    Console.WriteLine("Enter balance in account");
                    int bal1 = int.Parse(Console.ReadLine());
                    sv1.CalculateInterestHSBC(bal1);
                    break;
                default:
                    break;
            }
            Console.ReadKey();
        }
    }
}

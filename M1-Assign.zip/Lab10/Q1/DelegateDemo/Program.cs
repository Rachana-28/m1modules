﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    public delegate void ArithmeticHandler(int firstNumber, int secondNumber);

    public class Operations
    {
        public void Addition(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Addtion of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber + secondNumber);

        }
        public void Subtraction(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Subtraction of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber - secondNumber);

        }
        public void Multiply(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Multiplication of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber*secondNumber);
        }
        public void Divide(int first, int second)
        {
            Console.WriteLine("Divide of {0} and {1} is {2}", first, second, first/second);
        }
        public void FindMax(int first, int second)
        {
            
            Console.WriteLine("Max of {0} and {1} is {2}", first, second, Math.Max(first,second));
        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            Operations operationObj = new Operations();
            ArithmeticHandler arithObj1, arithObj2, arithObj3, arithobj4, arithobj5;

            Console.WriteLine("Enter 2 numbers");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your choice");
            Console.WriteLine("1.Add Numbers\n2.Multiply Numbers\n3.Divide Numbers\n4.Subtract Numbers\n5.Find max numbers");
            int choice = int.Parse(Console.ReadLine());

            switch(choice)
            {
                case 1:
                    arithObj1 = new ArithmeticHandler(operationObj.Addition);
                    arithObj1.Invoke(a, b);
                    break;
                case 2:
                    arithObj2 = new ArithmeticHandler(operationObj.Multiply);
                    arithObj2.Invoke(a, b);
                    break;
                case 3:
                    arithObj3 = new ArithmeticHandler(operationObj.Divide);
                    arithObj3.Invoke(a, b);
                    break;
                case 4:
                    arithobj4 = new ArithmeticHandler(operationObj.Subtraction);
                    arithobj4.Invoke(a, b);
                    break;
                case 5:
                    arithobj5 = new ArithmeticHandler(operationObj.FindMax);
                    arithobj5.Invoke(a, b);
                    break;
                default:
                    break;


            }
            Console.ReadKey();
        }
    }
}

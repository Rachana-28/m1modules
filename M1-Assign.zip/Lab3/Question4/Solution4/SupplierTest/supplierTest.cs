﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierTest1
{
    public class SupplierTest
    {
        public int SupplierID { get; set; }
        public string SupplierName { get; set; }
        public string city { get; set; }
        public string PhoneNo { get; set; }
        public string Email { get; set; }
    }

    public SupplierTest()
    {

    }

    







}

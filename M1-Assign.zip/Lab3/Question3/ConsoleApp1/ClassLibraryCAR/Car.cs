﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryCAR
{
    public class Car
    {
        public string CarMake { get; set; }
        public int CarModel { get; set; }
        public string CarYear { get; set; }
        public double CarPrice { get; set; }

       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDimensionalArray
{
    class ProductDemo
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[5, 6];
            Console.WriteLine("Enter elements of 2d array");
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    arr[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("2D-Array");

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    Console.Write(arr[i, j] +" ");
                }
                Console.WriteLine("  ");
            }
            Console.ReadKey();
                
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the id of the product");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name of the of the product");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Price");
            double price = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter quantity");
            int quan = int.Parse(Console.ReadLine());

            object id1 = id;
            object name1 = name;
            object price1 = price;
            object quan1 = quan;

            double pprice = (double)price1 * (int)quan1;
            Console.WriteLine("Product Details:");
            Console.WriteLine("Product ID- " + (int)id1);
            Console.WriteLine("Product name- " + (string)name1);
            Console.WriteLine("Product price- " + (double)price1);
            Console.WriteLine("Product quantity- " + (int)quan1);
            Console.WriteLine("Amount Payable- " + pprice);

            Console.ReadKey();



        }
    }
}

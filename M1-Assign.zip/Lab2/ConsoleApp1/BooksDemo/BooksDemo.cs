﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooksDemo
{
    class BooksDemo
    {
        static void Main(string[] args)
        {
            string[,] book = new string[2,4];
            Console.WriteLine("enter Book details");
            
            for(int i = 0;i<2;i++)
            {
                
                Console.WriteLine("Book title, Book Author, Book publisher, Price for  " + (i+1) + " Book");
                for (int j = 0;j<4;j++)
                {
                    book[i, j] = Console.ReadLine();
                }
            }
            Console.WriteLine("******************************************************************");
            Console.WriteLine("\tBook Title\t Book Author\t Book Publisher\t Book Price");
            Console.WriteLine("******************************************************************");
            for(int i=0;i<2;i++)
            {
                Console.Write("Book-" + (i+1));
                for(int j=0;j<4;j++)
                {
                    Console.Write("\t\t"+book[i,j] + " ");

                }
                Console.WriteLine(" ");
            }
            Console.ReadKey();

        }
    }
}

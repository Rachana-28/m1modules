﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
                Console.WriteLine("Enter details of employee");
                Console.WriteLine("Enter EmployeeID");
                int Eid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Name of employee");
                string Ename = Console.ReadLine();
                Console.WriteLine("Enter address");
                string Eaddress = Console.ReadLine();
                Console.WriteLine("Enter Employee city");
                string Ecity = Console.ReadLine();
                Console.WriteLine("Enter Employee Department");
                string Edept = Console.ReadLine();
                Console.WriteLine("Enter employee salary");
                double Esalary = int.Parse(Console.ReadLine());
                

                Console.WriteLine("1.For Perks\n2.For Provident Fund");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch(ch)
                {
                    case 1:
                        Console.WriteLine("Enter employee perks");
                        int perks = int.Parse(Console.ReadLine());
                        ContractEmployee c = new ContractEmployee();
                        c.GetSalary(Esalary,perks);
                        break;
                    case 2:
                        Console.WriteLine("Enter Provident fund");
                        double Providentfund = int.Parse(Console.ReadLine());
                        PermanentEmployee p = new PermanentEmployee();
                        p.GetSalary(Esalary, Providentfund);
                        break;
                    default:
                        break;

                }

                


            
            Console.ReadKey();
        }
    }
}

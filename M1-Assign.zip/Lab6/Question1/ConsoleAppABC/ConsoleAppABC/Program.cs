﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryEntity;
using ClassLibraryInvalidCreditLimit;

namespace ConsoleAppABC
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter customer ID");
                int cid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter customer Name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Address");
                string add = Console.ReadLine();
                Console.WriteLine("Enter city");
                string city = Console.ReadLine();
                Console.WriteLine("Enter Phone no.");
                string no = Console.ReadLine();
                Console.WriteLine("Enter Credit Limit");
                double credit = double.Parse(Console.ReadLine());

                Customer c = new Customer(cid, name, add, city, no, credit);

                c.Display();
            }
            
            catch(InvalidCreditLimit ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}

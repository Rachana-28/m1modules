﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryMyException
{
    public class MyException : ApplicationException
    {
        public MyException()
        {

        }
        public MyException(string str) : base(str)
        {

        }

        public MyException(string str, Exception innerexce) : base(str, innerexce)
        {

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            //Convert args to integer
            foreach(Object obj in args)
            {
                a = Convert.ToInt32(obj);
                break;
            }
            
            switch(a)
            {
                case 1:
                    Console.WriteLine("The number is 1");
                    break;
                case 2:
                    Console.WriteLine("The number is 2");
                    break;
                case 3:
                    Console.WriteLine("The number is 3");
                    break;
                case 4:
                    Console.WriteLine("The number is 4");
                    break;
                case 5:
                    Console.WriteLine("The number is 5");
                    break;
                default:
                    Console.WriteLine("ERROR - You entered wrong number");
                    break;

            }
            Console.ReadKey();
        }
    }
}

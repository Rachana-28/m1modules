﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            Employee[] obj = new Employee[2];
            
            for (int i = 0; i < 2; i++)
            {


                Console.WriteLine("Enter details of employee");
                Console.WriteLine("Enter EmployeeID");
                int Eid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Name of employee");
                string Ename = Console.ReadLine();
                Console.WriteLine("Enter address");
                string Eaddress = Console.ReadLine();
                Console.WriteLine("Enter Employee city");
                string Ecity = Console.ReadLine();
                Console.WriteLine("Enter Employee Department");
                string Edept = Console.ReadLine();
                Console.WriteLine("Enter employee salary");
                double Esalary = int.Parse(Console.ReadLine());

                Employee e = new Employee(Eid, Ename, Eaddress, Ecity, Edept, Esalary);
                e.DisplayInfo();
                Console.ReadKey();


            }
        }
    }
}

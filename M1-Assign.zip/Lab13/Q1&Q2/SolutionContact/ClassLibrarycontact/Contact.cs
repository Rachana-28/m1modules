﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryException;
namespace ClassLibrarycontact

{
    [Serializable]
    public class Contact
    {
        //public static List<Contact> con = new List<Contact>();
        //private static string fileName = "Contact.txt";

        // private int contatno;
        public int Contactno { get; set; }

        // private string contactname;
        public string ContactName { get; set; }

        //private long cellno;
        public long CellNo { get; set; }

        //public static void SetList()
        //{
        //    DeserializeFile();
        //}

        //private static void DeserializeFile()
        //{
        //    try
        //    {

        //        using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName, FileMode.Open))
        //        {
        //            BinaryFormatter bf = new BinaryFormatter();
        //            con = bf.Deserialize(file) as List<Contact>;
        //            file.Close();
        //        }
        //    }
        //    catch (MyException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // creating a dictionary object 
            // which takes integer as key and string as value
            Dictionary<int, string> dictionaryobj = new Dictionary<int, string>();
            // Adding elements to the dictionary
            dictionaryobj.Add(1, "Windows");
            dictionaryobj.Add(3, "Linux");
            dictionaryobj.Add(0, "DOS");
            dictionaryobj.Add(2, "Unix");
            Console.WriteLine("1.List all elements\n2.Search\n3.Update");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    // printing the dictionary elements using KeyValuePair<TKey, TValue> struct
                    foreach (KeyValuePair<int, string> pair in dictionaryobj)
                    {
                        Console.WriteLine("{0} {1}", pair.Key, pair.Value);
                    }
                    break;

                    //// Use var keyword to enumerate dictionary.
                    //foreach (var pair in dictionaryobj)
                    //{
                    //    Console.WriteLine("{0} {1}", pair.Key, pair.Value);
                    //}

                // See whether Dictionary contains this key.
                case 2:
                    Console.WriteLine("Enter index");
                    int n = int.Parse(Console.ReadLine());
                    foreach (var pair in dictionaryobj)
                    {
                        if (dictionaryobj.ContainsKey(n))
                        {

                            string value = dictionaryobj[n];
                            Console.WriteLine(value);
                        }
                        else
                        {
                            Console.WriteLine("No key found");
                        }
                    }
                    break;
                case 3:
                    Console.WriteLine("Enter index");
                    int n1 = int.Parse(Console.ReadLine());

                    foreach (var pair in dictionaryobj)
                    {
                        if (dictionaryobj.ContainsKey(n1))
                        {
                            Console.WriteLine("Enter new value");
                            string updatedvalue = Console.ReadLine();
                            dictionaryobj[n1] = updatedvalue;
                            Console.WriteLine("Value updated");
                        }
                    }
                    break;
                default:
                    break;
            }


            //        // Use TryGetValue.
            //        string test;
            //if (dictionaryobj.TryGetValue(0, out test)) // Returns true.
            //{
            //    Console.WriteLine(test); // This is the value at 0.
            //}
            //if (dictionaryobj.TryGetValue(5, out test)) // Returns false.
            //{
            //    Console.WriteLine(test); // Not reached.
            //}
            Console.ReadKey();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;

namespace ConsoleAppContact
{
    class Program
    {
        //create an object of hastable
        public static Hashtable HT = new Hashtable();
        static void Main(string[] args)
        {
            int choice;
            do
            {
                Console.WriteLine("\n\t\t1.Add Record \n\t\t2.Search record \n\t\t3.Total counts\n\t\t4.Show All Records \n\t\t5.Exit");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddContact();
                        break;
                    case 2:
                        FindContact();
                        break;
                    case 3:
                        TotalCounts();
                        break;
                    case 4:
                        ShowAllContact();
                        break;
                    default:
                        break;
                }
            }
            while (choice != 5);
            Console.ReadKey();
        }

        //function to add a record
        private static void AddContact()
        {
            Console.WriteLine("\n\t\tEnter Record ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter key");
            int key = int.Parse(Console.ReadLine());
            HT.Add(key, name);
            Console.WriteLine("\t\tRecord added \n");
        }

        //function to display all records
        private static void ShowAllContact()
        {
            ICollection keys = HT.Keys;
            foreach(Object k in keys)
            { 
                //Console.WriteLine("HashTable");
                Console.WriteLine();
                
                Console.WriteLine(HT[k]);
            }
        }

        //function to find a record
         private static void FindContact()
         {
            Console.WriteLine("Enter value");
            string val = Console.ReadLine();
            if (HT.ContainsValue(val))
            {
                Console.WriteLine("Record found");
            }
            else
            {
                Console.WriteLine("No record found");
            }
         }

        //function to get total count of records
        private static void TotalCounts()
        {
            Console.WriteLine(HT.Count);
        }

        //function to delete a record
        private static void DeleteRecord()
        {
            Console.WriteLine("enter the pin to be deleted:");
            string deletepin = Console.ReadLine();
            hashtable.Remove(deletepin);
        }
        
    }
}
